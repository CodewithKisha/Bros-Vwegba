These files are only needed if you intend to use Unsemantic in a React project via NPM, and are otherwise useless.

They do not need to be loaded in the browser in order for the Sass/CSS to work.